var a='15aa';
console.log(isNaN(a));
if (isNaN(a)==false) {
	console.log('reqem')
}else{
	console.log('text')
}
function btnSubmitClick() {
	var input1=document.getElementById('myInput');
	input1.value='salam Seid';

	console.log(input1.value.length);
}
/**********/
// var myDiv=document.getElementById('div15');
// console.log(myDiv);
// console.log(myDiv.innerText);
// console.log(myDiv.innerHTML);
// //myDiv.innerText='<span>text from js</span>';
// myDiv.innerHTML='<span>text from js</span>';

// document.write('Hello');


/*****************/
// var arr1=[1,2,3];
// console.log(arr1);

// var arr2=[4,5,6];
// console.log(arr2);

// var arr6=[7,8,9];
// console.log(arr6);


// var arr3=arr1.concat(arr2);
// console.log(arr3);

// var arr4=arr2.concat(arr1,arr6);
// console.log(arr4);


// var str='';
// for (var i = 0; i < arr4.length; i++) {
// 	//str=str+arr4[i]+'*';
// 	str+=arr4[i];
// }
// console.log(str);

// console.log(arr4.join('*'));

/*********************/

// var studentArr=
// [
// 	{
// 		name:'Yasin',
// 		surname:'Quliyev'
// 	}
// ];

// var obj1={};
// obj1.name='Yasin 2';
// obj1.surname='Quliyev 2';
// studentArr.push(obj1);

// var obj={
// 		name:'Yasin 1',
// 		surname:'Quliyev 1'
// };
// studentArr.push(obj);

// studentArr.push(
// 					{
// 						name:'Yasin 2',
// 						surname:'Quliyev 2'
// 					}
// 				);

// studentArr.push('test2');
// studentArr.push('test3');
//console.log(studentArr);