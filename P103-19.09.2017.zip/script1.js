var newDiv = document.createElement('div');
var divtext = document.createTextNode("text yazildi");
newDiv.appendChild(divtext);

var cavabElement=document.getElementById('cavab');

console.log(document.body.children[0]);

 var eded2Element=document.getElementById('eded2');

// //cavabElement.appendChild(newDiv);
 document.body.insertBefore(newDiv,eded2Element);
 //document.body.insertBefore(newDiv,document.body.children[3]);
 //console.log(eded2Element.nextSibling);










