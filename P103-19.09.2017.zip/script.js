/*
var a=15;


// console.log(Math.pow(a,5));

// var netice=a*a*a;

// console.log(netice);

console.log(Math.sqrt(25));

console.log(Math.abs(a));

console.log(Math.sign(a));

var sign=Math.sign(a);

// if (sign===-1) {
// 	console.log('menfi');
// }else if(sign===0){
// 	console.log('0');
// }else if(sign===1){
// 	console.log('musbet');
// }

switch(sign){
	case 0:
	case 1:
		console.log('musbet');
		break;	

	case -1:
		console.log('menfi');
		break;
}


var b=3;

console.log(Math.floor(b)); //3
console.log(Math.ceil(b)); //4
console.log(Math.round(b)); //4

console.log(b)
console.log(b.toFixed(2));

*/


function funbtnhesab() {
	var eded1=document.getElementById('eded1').value;
	var eded2=document.getElementById('eded2').value;
/*	var eded1kub=Math.pow(eded1,3);
	var eded2kub=Math.pow(eded2,3);
	var hesabkub=eded1kub*eded2kub;*/
	eded1=Math.pow(eded1,3);
	eded2=Math.pow(eded2,3);


	 var cavabElement=document.getElementById('cavab');
	// console.log(cavabElement);

	// //cavabElement.innerText=(eded1*eded2).toFixed(3);

	// document.getElementById('cavab').innerText=(eded1*eded2).toFixed(3);
	// document.getElementById('cavab').style.color='red';

	cavabElement.innerText=(eded1*eded2).toFixed(3);
	cavabElement.style.color='red';

}

