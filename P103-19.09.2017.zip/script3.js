var text=document.getElementById('hea0

text.addEventListener('mouseover', function() {
	text.style.color="red";
	text.innerText='welcome';
	text.style.transform='scale(1.5,1.5)';
});

text.addEventListener('mouseout', function() {
	text.style.color='green';
	text.innerText='ders bitti';
	text.style.transform='scale(1,1)';
});






var eded1Input=document.getElementById('eded1');
var placeHolderText='Text daxil edin';
eded1	Input.value=placeHolderText;

eded1Input.addEventListener('focus',function () {
	if(eded1Input.value.trim()==='' ||
	 eded1Input.value===placeHolderText){
		eded1Input.value='';
	}
	eded1Input.style.color='red';
});
eded1Input.addEventListener('blur',function () {
	if(eded1Input.value.trim()===''){
		eded1Input.value=placeHolderText;
	}
	eded1Input.style.color='green';
});


var a=9;
console.log(a)
a=6;
console.log(a)
-+*//