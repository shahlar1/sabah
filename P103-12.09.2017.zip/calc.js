function minus(a,b) {

	console.log('abc);
	if (a>15 && b>5 ) {
		return a-b;
	}else{		
		return 0;
	}
}

var c=minus(20,6);	

console.log(c);