/*-----part 6------*/

function sum(a,b) {
	if (a<0) {
		a=0;
	}
	return	a+b;
}

function minus(a,b) {
	
}

var d=sum(-85,2);
 if (d>5) {
	console.log('5den boyuk');
 }else
 {
	console.log('5den kicik');
 }

/*-----part 5------*/

// var a='40';
// var b=5;

// var c = parseInt(a)-b;
// var d = a-b.toString();

// console.log(c);
// console.log(d);

// var text1='hello ';
// var text2='world';
// console.log(text1-text2);



/*-----part 4------*/

// var a='hEllo wOrld';
// var b=1;
// b=b.toString();


// console.log(a);
// console.log(a.toUpperCase());
// console.log(a.toLowerCase());
// console.log(a.length);
// console.log(a.substr(1,4));
// console.log(a.substring(1,4));
 //console.log(a.indexOf('l'));
 //console.log(a.indexOf('l',3));
 //console.log(a.lastIndexOf('l'));
// console.log(a.replace('wOrld','P103'));
//console.log("Eng,Rus,Turk".split(','));


// var c=1;
// var d='1';

// if (c.toString()===d) {
// 	console.log('beraberdir');
// }else{
// 	console.log('beraber deyil');
// }


/*-----part 3------*/

// function myFunc() {
// 	a=2;
// 	console.log(a);
// }


// myFunc();
// console.log(a);

/*-----part 2------*/
// var b;
// console.log(b);
// b='hello world';
// console.log(b);




/*-----part 1------*/

// var a=1;
// var b='1';

// if (a===b) {
// 	console.log('beraberdir');
// }else{
// 	console.log('beraber deyil');
// }

