
function writeList() {
	var list=
	[
		'Kenan',
		'Sahlar',
		'Yasin',
		'Yasin 1',
		'Yasin 2'
	];
	
	var listHtml='<ul>';
	for(var a=0;a<list.length;a++){
		listHtml=listHtml+'<li>'+list[a]+'</li>';
	}
	listHtml=listHtml+'</ul>';
	document.write(listHtml);
}


writeList();
