var a=0;

function dovr1() {
	if (a<10) {
		console.log(a);
		a++;
		dovr1();
	}	
}

dovr1();