var studentObj=
{
	name:"Yasin",
	surname:'Quliyev'
};


var studentArr=
[
	{
		name:"Yasin",
		surname:'Quliyev'
	},
	{
		name:"Yasin 1",
		surname:'Quliyev'
	},
	{
		name:"Yasin 2",
		surname:'Quliyev'
	},	
];

console.log(studentArr[2])
console.log(studentArr[2].name)

//console.log(studentArr);



// var b='1';
// b=b+'2'; // 12
// b=b+'3';   // 123

// console.log(b);

//console.log(document);

// var a='div text';

// document.write('<div class="test">'+
// 				a+
// 				'</div>');

/********************/

// var a='101';

// console.log(parseInt(a));
// console.log(parseInt(a,5));

/********************/

// var a=0;
// var b=true;

// do{
// 	console.log(a);
// 	a++;
// 	if (a==2) {
// 		b=true;
// 	}
// }
// while(b==false)

// console.log('----');
//  a=0;
//  b=true;

// while(b==false){
// 	console.log('hello');

// 	if (b==false) {
// 		b=true;
// 	}
// }



/*----------------*/


// var studentObj={
// 	name:'Yasin',
// 	surname:'Quliyev',
// 	age:22
// };

// studentObj["name"]="Test";

// studentObj.class="P103";

// console.log(studentObj);

// delete studentObj["name"];

// console.log(studentObj);

// var a=0;
// var b=false;

// while(b==false){
// 	console.log(a);
// 	a++;
// 	if (a>2) {
// 		b=true;
// 	}
// }

//console.log(a);

// var arr=['Shahlar','Quliyev','Test'];
// console.log(arr.length);

// for (var i = 0; i < arr.length; i++) {
// 	console.log(arr[i]);
// }


/**********************/

// var a=9;

// 	if (a>5) {	
// 		throw new Error('a deyiseni 9dan boyuk ola bilmez');
// 		console.log(a);
// 	}
// 	console.log('finish');


// try{
// 	console.log('try start');
// 	var a=9;

// 	throw new Error('a deyiseni 5dan boyuk ola bilmez');

// 	if (a>5) {	
// 		console.log(a);
// 	}

// }
// catch(errorhghgf){
// 	console.log('catch');
// 	 console.error(errorhghgf);
// }
// finally{
// 	console.log('finally');
// }


// console.log('finish');